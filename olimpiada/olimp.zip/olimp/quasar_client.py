"""CHVT 2026 simulation client for the Quasar project bridge.

OpenCV is provided by the offline Quasar Jupyter runtime for crane camera frames.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
import math
import os
import queue
import secrets
import socket
import struct
import threading
import time
from dataclasses import dataclass
from typing import Any, Optional
from urllib.parse import urlsplit

PROTOCOL_VERSION = 1
MAX_FRAME_BYTES = 64 * 1024
MAX_MESSAGE_BYTES = 64 * 1024
COMMAND_PREFIX = "2026.chvt.final."
DEVICE_COMMAND_REJECTION_REASONS = {"crc8-mismatch", "payload-length-mismatch"}


def _crc8(payload: bytes) -> int:
    value = 0
    for byte in payload:
        value ^= byte
        for _ in range(8):
            value = ((value << 1) ^ 0x07) & 0xFF if value & 0x80 else (value << 1) & 0xFF
    return value


def validate_device_command(packet: dict[str, Any]) -> Optional[str]:
    """Return a rejection reason for an invalid packet, otherwise None."""
    if not isinstance(packet, dict):
        raise ValueError("packet must be a dictionary")
    try:
        canonical = {
            "sourceDeviceId": packet["sourceDeviceId"],
            "targetDeviceId": packet["targetDeviceId"],
            "commandCode": packet["commandCode"],
            "payload": packet["payload"],
        }
        metadata = packet["metadata"]
        expected_crc = packet["crc8"]
        payload_length = metadata["payloadLength"]
    except (KeyError, TypeError) as error:
        raise ValueError("packet does not match the documented command schema") from error
    encoded_payload = json.dumps(packet["payload"], ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if payload_length != len(encoded_payload):
        return "payload-length-mismatch"
    encoded = json.dumps(canonical, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if isinstance(expected_crc, bool) or not isinstance(expected_crc, int) or expected_crc != _crc8(encoded):
        return "crc8-mismatch"
    return None


class QuasarClientError(RuntimeError):
    """Base error raised by the project client."""


class QuasarConfigurationError(QuasarClientError):
    """Required bridge environment is absent or unsafe."""


class QuasarConnectionError(QuasarClientError):
    """The one-time bridge connection failed or was closed."""

    def __init__(
            self,
            message: str,
            *,
            code: str = "connection-closed",
            source: str = "unknown",
            recovery: Optional[str] = None,
    ):
        super().__init__(message)
        self.code = code
        self.source = source
        self.recovery = recovery

    def _fresh(self) -> "QuasarConnectionError":
        return QuasarConnectionError(
            str(self),
            code=self.code,
            source=self.source,
            recovery=self.recovery,
        )


class QuasarProtocolError(QuasarClientError):
    """The bridge returned an invalid protocol message."""


class QuasarTimeoutError(QuasarClientError):
    """A command or subscription timed out."""


class QuasarRunStoppedError(QuasarClientError):
    """The host stopped the active simulation run."""


_BRIDGE_CLOSE_GUIDANCE = {
    "run-reconnect-required": (
        "The simulator prepared a new run, so this kernel belongs to the previous run.",
        "Restart the Jupyter kernel, run all cells, and then start the prepared simulation.",
    ),
    "rate-limit": (
        "The project bridge stopped because the client exceeded 100 messages per second.",
        "Reduce polling, skip missed timer ticks, and avoid concurrent commands. Then restart the project environment.",
    ),
    "request-invalid": (
        "The project bridge rejected a duplicate request ID or more than 128 pending requests.",
        "Remove concurrent calls and wait for command responses. Then restart the project environment.",
    ),
    "idle-timeout": (
        "The project bridge received no client message for 30 seconds.",
        "Check that the kernel and reader thread are not blocked. Then restart the project environment.",
    ),
    "handshake-timeout": (
        "The Python client did not finish the project bridge handshake within 5 seconds.",
        "Restart the project environment, prepare a run, restart the kernel, and run all cells.",
    ),
    "backpressure": (
        "The project bridge stopped because the client was not reading messages fast enough.",
        "Reduce telemetry and event traffic and drain bounded queues. Then restart the project environment.",
    ),
    "frame-oversized": (
        "The project bridge received a frame larger than 64 KiB.",
        "Reduce the command or telemetry payload. Then restart the project environment.",
    ),
    "payload-too-deep": (
        "The project bridge received a payload nested more than 16 levels.",
        "Simplify the payload. Then restart the project environment.",
    ),
    "client-disconnected": (
        "The Python client disconnected, so the simulator stopped the current run.",
        "Prepare a new run, restart the Jupyter kernel, run all cells, and start the simulation.",
    ),
    "tool-stopped": (
        "The project environment was stopped by the host.",
        "Start the project environment again before creating a new client.",
    ),
    "tool-process-exited": (
        "The Jupyter project process exited.",
        "Restart the project environment and inspect its runtime log if the failure repeats.",
    ),
}


def _connection_error(reason: Optional[str], source: str) -> QuasarConnectionError:
    code = reason if isinstance(reason, str) and reason else "connection-closed"
    guidance = _BRIDGE_CLOSE_GUIDANCE.get(code)
    if guidance is None:
        if code in {"connection-closed", "session-closed"}:
            summary = "The project bridge connection ended before the client received a specific reason."
        else:
            summary = f"The project bridge closed the session ({code})."
        recovery = (
            "Check the simulator diagnostic. Restart the kernel for a newly prepared run; "
            "restart the project environment if the simulator reports a bridge failure."
        )
    else:
        summary, recovery = guidance
    return QuasarConnectionError(
        f"{summary} Recovery: {recovery}",
        code=code,
        source=source,
        recovery=recovery,
    )


class QuasarCommandError(QuasarClientError):
    """A runtime command was rejected."""

    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


@dataclass(frozen=True)
class RuntimeEvent:
    event_id: str
    payload: dict[str, Any]


@dataclass(frozen=True)
class TelemetrySample:
    channel_id: str
    timestamp_ms: int
    payload: dict[str, Any]

    def decoded_json(self) -> Any:
        if self.payload.get("encoding") != "base64":
            raise QuasarProtocolError("Unsupported telemetry encoding")
        try:
            raw = base64.b64decode(self.payload["data"], validate=True)
            return json.loads(raw.decode("utf-8"))
        except (KeyError, ValueError, UnicodeDecodeError, json.JSONDecodeError) as error:
            raise QuasarProtocolError("Invalid telemetry payload") from error


@dataclass(frozen=True)
class CameraObservation:
    frame: Any
    frame_id: str
    fault: dict[str, Any]


class _WebSocket:
    def __init__(self, bridge_url: str, capability: str, timeout: float):
        parsed = urlsplit(bridge_url)
        if parsed.scheme != "ws" or parsed.hostname != "127.0.0.1" or not parsed.port:
            raise QuasarConfigurationError("Bridge URL must use an explicit loopback ws endpoint")
        if parsed.path != "/project" or parsed.query or parsed.fragment:
            raise QuasarConfigurationError("Bridge URL path is invalid")

        self._socket = socket.create_connection((parsed.hostname, parsed.port), timeout=timeout)
        self._socket.settimeout(timeout)
        self._send_lock = threading.Lock()
        self.close_reason: Optional[str] = None
        self._receive_buffer = bytearray()
        key = base64.b64encode(secrets.token_bytes(16)).decode("ascii")
        request = (
            f"GET {parsed.path} HTTP/1.1\r\n"
            f"Host: {parsed.hostname}:{parsed.port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n"
            f"Authorization: Bearer {capability}\r\n\r\n"
        )
        self._socket.sendall(request.encode("ascii"))
        response = self._receive_headers()
        expected_accept = base64.b64encode(
            hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode("ascii")).digest()
        ).decode("ascii")
        lines = response.split("\r\n")
        headers = {
            name.strip().lower(): value.strip()
            for line in lines[1:]
            if ":" in line
            for name, value in [line.split(":", 1)]
        }
        if not lines[0].startswith("HTTP/1.1 101 ") or headers.get("sec-websocket-accept") != expected_accept:
            self._socket.close()
            raise QuasarConnectionError("Project bridge rejected the WebSocket handshake")
        self._socket.settimeout(1.0)

    def _receive_headers(self) -> str:
        data = bytearray()
        while b"\r\n\r\n" not in data:
            chunk = self._socket.recv(1024)
            if not chunk:
                raise QuasarConnectionError("Project bridge closed during handshake")
            data.extend(chunk)
            if len(data) > 16 * 1024:
                raise QuasarProtocolError("WebSocket response headers are too large")
        header_bytes, remainder = bytes(data).split(b"\r\n\r\n", 1)
        self._receive_buffer.extend(remainder)
        return header_bytes.decode("ascii", errors="strict")

    def send_json(self, message: dict[str, Any]) -> None:
        payload = json.dumps(message, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")
        if len(payload) > MAX_FRAME_BYTES:
            raise QuasarProtocolError("Outgoing frame exceeds 64 KiB")
        self._send_frame(0x1, payload)

    def receive_json(self) -> Optional[dict]:
        fragments: Optional[bytearray] = None
        while True:
            opcode, payload = self._receive_frame()
            if opcode == 0x8:
                if fragments is not None:
                    raise QuasarProtocolError("WebSocket closed during fragmented text message")
                if len(payload) == 1:
                    raise QuasarProtocolError("invalid WebSocket close frame")
                if len(payload) >= 2:
                    try:
                        self.close_reason = payload[2:].decode("utf-8") or None
                    except UnicodeDecodeError as error:
                        raise QuasarProtocolError("invalid WebSocket close reason") from error
                return None
            if opcode == 0x9:
                self._send_frame(0xA, payload)
                continue
            if opcode == 0xA:
                continue
            if opcode == 0x1:
                if fragments is not None:
                    raise QuasarProtocolError("Nested WebSocket text message")
                fragments = bytearray(payload)
            elif opcode == 0x0:
                if fragments is None:
                    raise QuasarProtocolError("Unexpected WebSocket continuation frame")
                fragments.extend(payload)
            else:
                raise QuasarProtocolError("Unsupported WebSocket opcode")
            if len(fragments) > MAX_MESSAGE_BYTES:
                raise QuasarProtocolError("Incoming WebSocket message exceeds 64 KiB")
            if not self._last_frame_fin:
                continue
            payload = bytes(fragments)
            fragments = None
            try:
                message = json.loads(payload.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as error:
                raise QuasarProtocolError("Bridge sent invalid JSON") from error
            if not isinstance(message, dict):
                raise QuasarProtocolError("Bridge message must be an object")
            return message

    def close(self) -> None:
        try:
            self._send_frame(0x8, struct.pack("!H", 1000))
        except OSError:
            pass
        finally:
            try:
                self._socket.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            self._socket.close()

    def _send_frame(self, opcode: int, payload: bytes) -> None:
        mask = secrets.token_bytes(4)
        length = len(payload)
        if length < 126:
            header = struct.pack("!BB", 0x80 | opcode, 0x80 | length)
        elif length <= 0xFFFF:
            header = struct.pack("!BBH", 0x80 | opcode, 0x80 | 126, length)
        else:
            header = struct.pack("!BBQ", 0x80 | opcode, 0x80 | 127, length)
        masked = bytes(value ^ mask[index % 4] for index, value in enumerate(payload))
        with self._send_lock:
            self._socket.sendall(header + mask + masked)

    def _receive_frame(self) -> tuple[int, bytes]:
        first, second = self._receive_exact(2)
        self._last_frame_fin = bool(first & 0x80)
        opcode = first & 0x0F
        if first & 0x70:
            raise QuasarProtocolError("WebSocket RSV bits are unsupported")
        if opcode >= 0x8 and (not self._last_frame_fin or (second & 0x7F) > 125):
            raise QuasarProtocolError("WebSocket control frames must be final and at most 125 bytes")
        if second & 0x80:
            raise QuasarProtocolError("Server WebSocket frames must not be masked")
        length = second & 0x7F
        if length == 126:
            length = struct.unpack("!H", self._receive_exact(2))[0]
        elif length == 127:
            length = struct.unpack("!Q", self._receive_exact(8))[0]
        if length > MAX_FRAME_BYTES:
            raise QuasarProtocolError("Incoming frame exceeds 64 KiB")
        return opcode, self._receive_exact(length)

    def _receive_exact(self, size: int) -> bytes:
        data = bytearray()
        if self._receive_buffer:
            buffered = min(size, len(self._receive_buffer))
            data.extend(self._receive_buffer[:buffered])
            del self._receive_buffer[:buffered]
        while len(data) < size:
            chunk = self._socket.recv(size - len(data))
            if not chunk:
                raise QuasarConnectionError("Project bridge connection closed")
            data.extend(chunk)
        return bytes(data)


class QuasarClient:
    """Thread-safe command client with bounded event and telemetry queues."""

    def __init__(
            self,
            bridge_url: str,
            capability: str,
            session_id: str,
            timeout: float = 5.0,
            queue_size: int = 100,
    ):
        if not session_id or timeout <= 0 or not 1 <= queue_size <= 1000:
            raise QuasarConfigurationError("Invalid client configuration")
        self._timeout = timeout
        self._session_id = session_id
        self._socket = _WebSocket(bridge_url, capability, timeout)
        self._sequence = 0
        self._sequence_lock = threading.Lock()
        self._request_counter = 0
        self._pending: dict[str, queue.Queue[dict[str, Any]]] = {}
        self._pending_lock = threading.Lock()
        self._events: queue.Queue[RuntimeEvent] = queue.Queue(maxsize=queue_size)
        self._telemetry: queue.Queue[TelemetrySample] = queue.Queue(maxsize=queue_size)
        self._closed = threading.Event()
        self._run_started = threading.Event()
        self._stop_requested = threading.Event()
        self._run_state: Optional[str] = None
        self._run_id: Optional[str] = None
        self._reader_error: Optional[BaseException] = None
        self._inbound_sequence = -1
        self._last_ping = time.monotonic()
        self._enabled_incidents: set[str] = set()
        self._incident_seed: Optional[int] = None

        ready = self._socket.receive_json()
        self._validate_envelope(ready, "session.ready")
        if ready["payload"] != {"protocolVersion": PROTOCOL_VERSION}:
            raise QuasarProtocolError("Unsupported project bridge protocol")
        self._send("session.ready", {"protocolVersion": PROTOCOL_VERSION})
        self._reader = threading.Thread(target=self._reader_loop, name="quasar-project-bridge", daemon=True)
        self._reader.start()

    @classmethod
    def from_environment(cls, timeout: float = 5.0, queue_size: int = 100) -> "QuasarClient":
        names = (
            "QUASAR_PROJECT_BRIDGE_URL",
            "QUASAR_PROJECT_BRIDGE_TOKEN",
            "QUASAR_PROJECT_BRIDGE_SESSION_ID",
        )
        values = [os.environ.get(name, "") for name in names]
        if not all(values):
            raise QuasarConfigurationError("Quasar project bridge environment is unavailable")
        return cls(values[0], values[1], values[2], timeout=timeout, queue_size=queue_size)

    def get_state(self) -> dict[str, Any]:
        return self._command("state.get", {})

    def configure_incidents(self, incident_ids: list[str] | tuple[str, ...]) -> dict[str, Any]:
        """Enable the activity's cyber incident triggers before starting an attempt."""
        if not isinstance(incident_ids, (list, tuple)):
            raise TypeError("incident_ids must be a list or tuple")
        allowed = {f"CybP_{index:02d}" for index in range(1, 6)}
        if (not all(isinstance(item, str) and item in allowed for item in incident_ids)
                or len(set(incident_ids)) != len(incident_ids)):
            raise ValueError("incident_ids must contain unique CybP_01 through CybP_05 values")
        result = self._command("incidents.configure", {"enabled": list(incident_ids)})
        seed = result.get("seed")
        if isinstance(seed, bool) or not isinstance(seed, int) or not 0 <= seed <= 0xFFFFFFFF:
            raise QuasarProtocolError("invalid incident seed")
        self._enabled_incidents = set(incident_ids)
        self._incident_seed = seed
        return result

    @property
    def simulation_running(self) -> bool:
        """True from the UI Start action until the host stops or completes the run."""
        return self._run_started.is_set() and not self._stop_requested.is_set()

    @property
    def stop_requested(self) -> bool:
        """Cooperative cancellation flag set by the UI Stop action or client close."""
        return self._stop_requested.is_set()

    @property
    def run_state(self) -> Optional[str]:
        return self._run_state

    def wait_for_simulation_start(self, timeout: Optional[float] = None) -> None:
        """Block an initialization cell until the user starts the prepared UI run."""
        deadline = self._deadline(timeout)
        while not self._run_started.is_set():
            self._assert_open()
            wait_time = self._remaining_wait(deadline, "Waiting for simulation start timed out")
            self._run_started.wait(wait_time)

    def wait_for_simulation_stop(self, timeout: Optional[float] = None) -> None:
        """Block until UI Stop or normal runtime completion requests cancellation."""
        deadline = self._deadline(timeout)
        while not self._stop_requested.is_set():
            self._assert_open()
            wait_time = self._remaining_wait(deadline, "Waiting for simulation stop timed out")
            self._stop_requested.wait(wait_time)

    def reset(self, seed: Optional[int] = None) -> dict[str, Any]:
        if seed is not None and (isinstance(seed, bool) or not isinstance(seed, int) or not 0 <= seed <= 0xFFFFFFFF):
            raise ValueError("seed must be an integer from 0 to 4294967295")
        return self._command("reset", {} if seed is None else {"seed": seed})

    def start_attempt(self) -> dict[str, Any]:
        return self._command("attempt.start", {})

    def stop_attempt(self) -> dict[str, Any]:
        return self._command("attempt.stop", {})

    def set_robot_magnet(self, robot_id: str, enabled: bool) -> dict[str, Any]:
        """Set the commanded magnet state of robot.1 or robot.2."""
        if robot_id not in {"robot.1", "robot.2"}:
            raise ValueError("robot_id must be robot.1 or robot.2")
        if not isinstance(enabled, bool):
            raise TypeError("enabled must be a boolean")
        return self._command("robot.set-magnet", {"robotId": robot_id, "enabled": enabled})

    def execute_gcode(
        self,
        device_id: str,
        program: str | list[str] | tuple[str, ...],
        wait: bool = True,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        """Execute a bounded device-specific G-code program and optionally wait for its queue."""
        command_by_device = {
            "robot.1": ("robot.gcode.execute", "robotId"),
            "robot.2": ("robot.gcode.execute", "robotId"),
            "crane.1": ("crane.gcode.execute", "craneId"),
            "train.1": ("train.gcode.execute", "trainId"),
        }
        if device_id not in command_by_device:
            raise ValueError("device_id must be robot.1, robot.2, crane.1, or train.1")
        if isinstance(program, (list, tuple)):
            if not all(isinstance(line, str) for line in program):
                raise TypeError("all G-code lines must be strings")
            source = "\n".join(program)
        elif isinstance(program, str):
            source = program
        else:
            raise TypeError("program must be a string or a list/tuple of strings")
        if not source.strip() or len(source) > 8192:
            raise ValueError("G-code program must contain 1 to 8192 characters")
        if not isinstance(wait, bool):
            raise TypeError("wait must be a boolean")
        timeout_value = float(timeout)
        if not math.isfinite(timeout_value) or timeout_value <= 0:
            raise ValueError("timeout must be finite and positive")
        command, id_field = command_by_device[device_id]
        accepted = self._command(command, {id_field: device_id, "program": source})
        if not wait:
            return accepted
        deadline = time.monotonic() + timeout_value
        while True:
            state = self.get_state()
            if device_id == "crane.1":
                device = state.get("crane")
            elif device_id == "train.1":
                device = state.get("train")
            else:
                robots = state.get("robots")
                device = next((robot for robot in robots if isinstance(robot, dict) and robot.get("id") == device_id), None) if isinstance(robots, list) else None
            gcode = device.get("gcode") if isinstance(device, dict) else None
            if not isinstance(gcode, dict):
                raise QuasarProtocolError(f"Runtime state has no G-code status for {device_id}")
            error_code = gcode.get("lastError")
            if error_code:
                raise QuasarCommandError(str(error_code))
            if gcode.get("busy") is False:
                return gcode
            if time.monotonic() >= deadline:
                raise QuasarTimeoutError(f"G-code program for {device_id} timed out; queued motion was not cancelled")
            time.sleep(min(0.05, max(0.0, deadline - time.monotonic())))

    def apply_safety_limit(self, value: float) -> dict[str, Any]:
        limit = float(value)
        if not math.isfinite(limit) or limit < 0:
            raise ValueError("safety limit must be finite and non-negative")
        return self._command("security.apply-limit", {"value": limit})

    def append_log(
            self,
            level: str,
            incident_id: str,
            message: str,
            details: Optional[dict[str, str | int | float | bool]] = None,
    ) -> dict[str, Any]:
        if not isinstance(level, str) or level not in {"info", "warning", "error"}:
            raise ValueError("level must be info, warning, or error")
        if not isinstance(incident_id, str):
            raise TypeError("incident_id must be a string")
        incident_id = incident_id.strip()
        if not incident_id or len(incident_id) > 100:
            raise ValueError("incident_id must contain 1 to 100 characters")
        if not isinstance(message, str):
            raise TypeError("message must be a string")
        message = message.strip()
        if not message or len(message) > 300:
            raise ValueError("message must contain 1 to 300 characters")
        if details is not None:
            if (not isinstance(details, dict) or len(details) > 12
                    or any(not isinstance(key, str) or not key or len(key) > 40 for key in details)
                    or any(isinstance(value, float) and not math.isfinite(value)
                           or not isinstance(value, (str, int, float, bool)) for value in details.values())):
                raise ValueError("details must contain at most 12 bounded scalar fields")
            if any(isinstance(value, str) and len(value) > 160 for value in details.values()):
                raise ValueError("details string values must contain at most 160 characters")
        return self._command("log.append", {
            "level": level,
            "incidentId": incident_id,
            "message": message,
            **({"details": details} if details is not None else {}),
        })

    def notify_nodes(self, target_ids: list[str], action: str) -> dict[str, Any]:
        if (not isinstance(target_ids, list) or not 1 <= len(target_ids) <= 4
                or len(set(target_ids)) != len(target_ids)
                or any(item not in {"robot.1", "robot.2", "train.1", "crane.1", "dispatcher"}
                       for item in target_ids)):
            raise ValueError("target_ids must contain one to four unique scenario node IDs")
        if not isinstance(action, str) or not action.strip() or len(action.strip()) > 200:
            raise ValueError("action must contain 1 to 200 characters")
        return self._command("dispatcher.notify", {"targetIds": target_ids, "action": action.strip()})

    def get_pending_device_commands(self) -> dict[str, Any]:
        return self._command("device-command.list", {})

    def reject_device_command(self, sequence: int, device_id: str, reason: str) -> dict[str, Any]:
        if isinstance(sequence, bool) or not isinstance(sequence, int) or sequence < 1:
            raise ValueError("sequence must be a positive integer")
        self._validate_controllable_device(device_id)
        if reason not in DEVICE_COMMAND_REJECTION_REASONS:
            raise ValueError("reason must be crc8-mismatch or payload-length-mismatch")
        return self._command("device-command.reject", {
            "sequence": sequence,
            "deviceId": device_id,
            "reason": reason,
        })

    def report_compromised_device(self, device_id: str, reason: str) -> dict[str, Any]:
        self._validate_controllable_device(device_id)
        if not isinstance(reason, str) or not reason.strip() or len(reason.strip()) > 160:
            raise ValueError("reason must contain 1 to 160 characters")
        return self._command("device.report-compromised", {
            "deviceId": device_id,
            "reason": reason.strip(),
        })

    def list_firmware(self, device_id: str) -> dict[str, Any]:
        self._validate_controllable_device(device_id)
        return self._command("firmware.list", {"deviceId": device_id})

    def fetch_firmware(self, module_id: str) -> dict[str, Any]:
        self._validate_module_id(module_id)
        return self._command("firmware.fetch", {"moduleId": module_id})

    def get_firmware_hashes(self) -> dict[str, Any]:
        return self._command("firmware.hashes", {})

    def get_firmware_signatures(self) -> dict[str, Any]:
        return self._command("firmware.signatures", {})

    def verify_firmware(
            self, device_id: str, module_id: str, sha256_hex: str,
            signature_base64: str) -> dict[str, Any]:
        self._validate_controllable_device(device_id)
        self._validate_module_id(module_id)
        if (not isinstance(sha256_hex, str) or len(sha256_hex) != 64
                or any(character not in "0123456789abcdef" for character in sha256_hex)):
            raise ValueError("sha256_hex must be a lowercase SHA-256 hex digest")
        if not isinstance(signature_base64, str) or not signature_base64 or len(signature_base64) > 512:
            raise ValueError("signature_base64 must contain a bounded signature")
        try:
            base64.b64decode(signature_base64, validate=True)
        except (ValueError, binascii.Error) as error:
            raise ValueError("signature_base64 must be valid base64") from error
        return self._command("firmware.verify", {
            "deviceId": device_id,
            "moduleId": module_id,
            "sha256": sha256_hex,
            "signatureBase64": signature_base64,
        })

    def install_firmware(self, device_id: str, module_id: str, sha256_hex: str) -> dict[str, Any]:
        self._validate_controllable_device(device_id)
        self._validate_module_id(module_id)
        if (not isinstance(sha256_hex, str) or len(sha256_hex) != 64
                or any(character not in "0123456789abcdef" for character in sha256_hex)):
            raise ValueError("sha256_hex must be a lowercase SHA-256 hex digest")
        return self._command("firmware.install", {
            "deviceId": device_id,
            "moduleId": module_id,
            "sha256": sha256_hex,
        })

    @staticmethod
    def verify_firmware_signature(public_key_pem: str, file_base64: str, signature_base64: str) -> str:
        """Verify an ECDSA P-256 signature over SHA-256(file), returning its lowercase digest."""
        if not all(isinstance(value, str) and value for value in (public_key_pem, file_base64, signature_base64)):
            raise TypeError("firmware verification inputs must be non-empty strings")
        try:
            payload = base64.b64decode(file_base64, validate=True)
            signature = base64.b64decode(signature_base64, validate=True)
            from cryptography.exceptions import InvalidSignature
            from cryptography.hazmat.primitives import hashes, serialization
            from cryptography.hazmat.primitives.asymmetric import ec, utils
            public_key = serialization.load_pem_public_key(public_key_pem.encode("ascii"))
            digest = hashlib.sha256(payload).digest()
            public_key.verify(signature, digest, ec.ECDSA(utils.Prehashed(hashes.SHA256())))
        except InvalidSignature as error:
            raise QuasarProtocolError("firmware signature is invalid") from error
        except (ValueError, TypeError, binascii.Error, UnicodeEncodeError) as error:
            raise QuasarProtocolError("firmware verification metadata is invalid") from error
        return digest.hex()

    def execute_process_command(self, device_id: str, command: str) -> dict[str, Any]:
        self._validate_controllable_device(device_id)
        if not isinstance(command, str) or not command.strip() or len(command.strip()) > 200:
            raise ValueError("command must contain 1 to 200 characters")
        return self._command("process.exec", {"deviceId": device_id, "command": command.strip()})

    @staticmethod
    def _validate_controllable_device(device_id: str) -> None:
        if device_id not in {"robot.1", "robot.2", "train.1", "crane.1"}:
            raise ValueError("device_id must be robot.1, robot.2, train.1, or crane.1")

    @staticmethod
    def _validate_module_id(module_id: str) -> None:
        if (not isinstance(module_id, str) or not 1 <= len(module_id) <= 80
                or any(not (character.isascii() and (character.isalnum() or character in ".-_"))
                       for character in module_id)):
            raise ValueError("module_id must be a bounded ASCII identifier")

    def get_traffic_light_signal(self, traffic_light_id: str) -> dict[str, Any]:
        """Return the active signal while the train is within 0.3 m of its barrier."""
        if traffic_light_id not in {"traffic-light.1", "traffic-light.2"}:
            raise ValueError("traffic_light_id must be traffic-light.1 or traffic-light.2")
        return self._command("traffic-light.get-signal", {"trafficLightId": traffic_light_id})

    def request_barrier_open(self, barrier_id: str) -> dict[str, Any]:
        """Ask the dispatcher whether inspection is complete and movement is allowed."""
        if barrier_id not in {"barrier.1", "barrier.2"}:
            raise ValueError("barrier_id must be barrier.1 or barrier.2")
        return self._command("barrier.request-open", {"barrierId": barrier_id})

    def get_cargo_request(self) -> dict[str, Any]:
        return self._command("dispatcher.get-cargo-request", {})

    def get_container_cargo(self, marker_id: int) -> dict[str, Any]:
        return self._command("cargo-database.get-container", {"markerId": marker_id})

    def register_container_cargo(
        self,
        marker_id: int,
        items: list[dict[str, Any]],
        frame_id: Optional[str] = None,
    ) -> dict[str, Any]:
        if isinstance(marker_id, bool) or not isinstance(marker_id, int) or marker_id not in {30, 32, 33, 34, 35, 36}:
            raise ValueError("marker_id must be one of 30, 32, 33, 34, 35, or 36")
        if not isinstance(items, list) or not 1 <= len(items) <= 12:
            raise ValueError("items must contain 1 to 12 records")
        for item in items:
            if not isinstance(item, dict) or set(item) != {"nomenclature", "massKg"}:
                raise TypeError("each cargo item must contain nomenclature and massKg")
            nomenclature = item["nomenclature"]
            mass = item["massKg"]
            if not isinstance(nomenclature, str) or not nomenclature.strip() or len(nomenclature.strip()) > 120:
                raise ValueError("nomenclature must contain 1 to 120 characters")
            if isinstance(mass, bool) or not isinstance(mass, (int, float)) or not math.isfinite(mass) or not 0 < mass <= 100000:
                raise ValueError("massKg must be finite, positive, and at most 100000")
        if frame_id is not None and (not isinstance(frame_id, str) or not 1 <= len(frame_id) <= 100):
            raise ValueError("frame_id must contain 1 to 100 characters")
        return self._command("cargo-database.register-container", {
            "markerId": marker_id,
            "items": items,
            **({"frameId": frame_id} if frame_id is not None else {}),
        })

    def complete_unloading(self) -> dict[str, Any]:
        return self._command("dispatcher.complete-unloading", {})

    def get_crane_camera_observation(self, cyber_incident_enabled: Optional[bool] = None) -> CameraObservation:
        """Capture a frame together with raw integrity metadata used by the security module."""
        if cyber_incident_enabled is None:
            cyber_incident_enabled = "CybP_01" in getattr(self, "_enabled_incidents", set())
        elif not isinstance(cyber_incident_enabled, bool):
            raise TypeError("cyber_incident_enabled must be a boolean or None")
        incident_seed = getattr(self, "_incident_seed", None)
        if cyber_incident_enabled and (
                isinstance(incident_seed, bool) or not isinstance(incident_seed, int)):
            raise QuasarProtocolError("configure CybP_01 before requesting a faulted observation")
        metadata = self._command("camera.frame.capture", {
            "cyberIncidentEnabled": cyber_incident_enabled,
            "seed": incident_seed if cyber_incident_enabled else 0,
        })
        frame_id = metadata.get("frameId")
        media_type = metadata.get("mediaType")
        width = metadata.get("width")
        height = metadata.get("height")
        chunk_count = metadata.get("chunkCount")
        byte_length = metadata.get("byteLength")
        fault = metadata.get("fault")
        if (not isinstance(frame_id, str) or not frame_id or media_type != "image/jpeg"
                or width != 640 or height != 480 or isinstance(chunk_count, bool)
                or not isinstance(chunk_count, int) or not 1 <= chunk_count <= 100
                or isinstance(byte_length, bool) or not isinstance(byte_length, int)
                or byte_length <= 0 or byte_length > 1_800_000
                or not QuasarClient._valid_camera_fault_metadata(fault)):
            raise QuasarProtocolError("invalid camera frame metadata")
        chunks: list[str] = []
        for index in range(chunk_count):
            chunk = self._command("camera.frame.get-chunk", {"frameId": frame_id, "index": index})
            if (chunk.get("frameId") != frame_id or chunk.get("index") != index
                    or chunk.get("chunkCount") != chunk_count
                    or not isinstance(chunk.get("dataBase64"), str)):
                raise QuasarProtocolError("invalid camera frame chunk")
            data = chunk["dataBase64"]
            if not data or len(data) > 24_000 or len(data) % 4:
                raise QuasarProtocolError("invalid camera frame chunk size")
            chunks.append(data)
        if sum(len(chunk) for chunk in chunks) > 2_400_000:
            raise QuasarProtocolError("camera frame chunks exceed aggregate limit")
        try:
            encoded_bytes = base64.b64decode("".join(chunks), validate=True)
        except (ValueError, binascii.Error) as exc:
            raise QuasarProtocolError("invalid camera frame encoding") from exc
        if len(encoded_bytes) != byte_length:
            raise QuasarProtocolError("camera frame byte length mismatch")
        import cv2
        import numpy as np
        frame = cv2.imdecode(np.frombuffer(encoded_bytes, dtype=np.uint8), cv2.IMREAD_COLOR)
        if frame is None or frame.shape != (480, 640, 3):
            raise QuasarProtocolError("invalid camera frame image")
        return CameraObservation(frame=frame, frame_id=frame_id, fault=fault)

    def get_crane_camera_frame(self):
        """Capture a 640x480 image and return an OpenCV BGR ndarray."""
        return self.get_crane_camera_observation().frame

    @staticmethod
    def _valid_camera_fault_metadata(value: Any) -> bool:
        if not isinstance(value, dict) or set(value) != {
            "captureOrdinal", "episodeId", "episodeFrame", "integrity"
        }:
            return False
        if (isinstance(value["captureOrdinal"], bool)
                or not isinstance(value["captureOrdinal"], int)
                or value["captureOrdinal"] < 1):
            return False
        if value["episodeId"] is not None and (
                not isinstance(value["episodeId"], str)
                or not value["episodeId"].startswith("CybP_01.")):
            return False
        if value["episodeFrame"] is not None and (
                isinstance(value["episodeFrame"], bool)
                or not isinstance(value["episodeFrame"], int)
                or not 1 <= value["episodeFrame"] <= 3):
            return False
        if (value["episodeId"] is None) != (value["episodeFrame"] is None):
            return False
        integrity = value["integrity"]
        if not isinstance(integrity, dict) or set(integrity) != {
            "algorithm", "status", "columns", "rows", "expected", "observed"
        }:
            return False
        if (integrity["algorithm"] != "luma-grid-16x16-q4"
                or integrity["status"] not in {"ok", "mismatch"}
                or integrity["columns"] != 40 or integrity["rows"] != 30):
            return False
        for field in ("expected", "observed"):
            grid = integrity[field]
            if (not isinstance(grid, list) or len(grid) != 1_200
                    or any(isinstance(item, bool) or not isinstance(item, int) or not 0 <= item <= 15
                           for item in grid)):
                return False
        return True

    def log(self, level: str, message: str) -> None:
        """Send a project client message to the Quasar application journal."""
        if level not in {"debug", "info", "warning", "error"}:
            raise ValueError("level must be debug, info, warning, or error")
        if not isinstance(message, str):
            raise TypeError("message must be a string")
        normalized = message.strip()
        if not normalized:
            raise ValueError("message must not be empty")
        self._assert_open()
        self._send("client.log", {"level": level, "message": normalized[:500]})

    def debug(self, message: str) -> None:
        self.log("debug", message)

    def info(self, message: str) -> None:
        self.log("info", message)

    def warning(self, message: str) -> None:
        self.log("warning", message)

    def error(self, message: str) -> None:
        self.log("error", message)

    def next_event(self, timeout: Optional[float] = None) -> RuntimeEvent:
        return self._next(self._events, timeout)

    def next_telemetry(self, timeout: Optional[float] = None) -> TelemetrySample:
        return self._next(self._telemetry, timeout)

    def close(self) -> None:
        if self._closed.is_set():
            return
        self._run_started.clear()
        self._stop_requested.set()
        self._closed.set()
        self._socket.close()
        if threading.current_thread() is not self._reader:
            self._reader.join(timeout=1.0)
        self._fail_pending(QuasarConnectionError("Project bridge client closed"))

    def __enter__(self) -> "QuasarClient":
        return self

    def __exit__(self, _type: Any, _value: Any, _traceback: Any) -> None:
        self.close()

    def _command(self, command: str, payload: dict[str, Any]) -> dict[str, Any]:
        response = self._request(COMMAND_PREFIX + command, payload)
        result = response.get("result")
        if not response.get("success"):
            raise QuasarCommandError(str(response.get("errorCode", "runtime-failed")))
        if not isinstance(result, dict):
            raise QuasarProtocolError("Command result must be an object")
        return result

    def _request(self, command_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        self._assert_open()
        if self._stop_requested.is_set():
            raise QuasarRunStoppedError("Simulation stopped by host; restart the Jupyter kernel for a new run")
        with self._pending_lock:
            if len(self._pending) >= 128:
                raise QuasarClientError("Too many pending project bridge requests")
            self._request_counter += 1
            request_id = f"py.{self._request_counter}"
            response_queue: queue.Queue[dict[str, Any]] = queue.Queue(maxsize=1)
            self._pending[request_id] = response_queue
        try:
            self._send("runtime.command", {"commandId": command_id, "payload": payload}, request_id)
            try:
                response = response_queue.get(timeout=self._timeout)
            except queue.Empty as error:
                raise QuasarTimeoutError(f"Command timed out: {command_id}") from error
            if "_client_error" in response:
                error = response["_client_error"]
                if isinstance(error, QuasarConnectionError):
                    raise error._fresh() from None
                raise error
            return response
        finally:
            with self._pending_lock:
                self._pending.pop(request_id, None)

    def _reader_loop(self) -> None:
        try:
            while not self._closed.is_set():
                try:
                    message = self._socket.receive_json()
                except socket.timeout:
                    if time.monotonic() - self._last_ping >= 10:
                        self._send("session.ping", {"sentAtMs": int(time.time() * 1000)})
                        self._last_ping = time.monotonic()
                    continue
                if message is None:
                    raise _connection_error(self._socket.close_reason, "websocket-close")
                self._validate_envelope(message)
                message_type = message["type"]
                payload = message["payload"]
                if message_type == "runtime.result":
                    request_id = message.get("requestId")
                    with self._pending_lock:
                        response_queue = self._pending.get(request_id)
                    if response_queue:
                        response_queue.put_nowait(payload)
                elif message_type == "runtime.event":
                    self._put_bounded(self._events, RuntimeEvent(payload["eventId"], payload["payload"]))
                elif message_type == "runtime.telemetry":
                    self._put_bounded(self._telemetry, TelemetrySample(
                        payload["channelId"], payload["timestampMs"], payload["payload"]
                    ))
                elif message_type == "run.lifecycle":
                    self._apply_run_lifecycle(payload)
                elif message_type == "session.ping":
                    self._send("session.pong", payload)
                elif message_type == "session.pong":
                    pass
                elif message_type in {"session.closed", "session.error"}:
                    reason = payload.get("reason") or payload.get("code")
                    raise _connection_error(str(reason) if reason else None, message_type)
                else:
                    raise QuasarProtocolError(f"Unexpected bridge message: {message_type}")
                self._maybe_ping()
        except (OSError, QuasarClientError, KeyError, TypeError) as error:
            self._reader_error = error
            self._run_started.clear()
            self._stop_requested.set()
            self._closed.set()
            self._fail_pending(error)

    def _apply_run_lifecycle(self, payload: dict[str, Any]) -> None:
        state = payload.get("state")
        run_id = payload.get("runId")
        if state not in {"preparing", "ready", "running", "stopped"} or not isinstance(run_id, str) or not run_id:
            raise QuasarProtocolError("Invalid run lifecycle message")
        if self._run_id is None:
            self._run_id = run_id
        elif run_id != self._run_id:
            # A reconnect is a new client lifecycle; stale notifications must not
            # change the state bound to this socket.
            return
        self._run_state = state
        if state == "running":
            if not self._stop_requested.is_set():
                self._run_started.set()
        elif state == "stopped":
            self._run_started.clear()
            self._stop_requested.set()
            self._fail_pending(QuasarRunStoppedError("Simulation stopped by host"))
        else:
            self._run_started.clear()

    def _validate_envelope(
        self,
        message: Optional[dict],
        expected_type: Optional[str] = None,
    ) -> None:
        if not isinstance(message, dict):
            raise QuasarProtocolError("Missing project bridge message")
        if message.get("protocolVersion") != PROTOCOL_VERSION or message.get("sessionId") != self._session_id:
            raise QuasarProtocolError("Project bridge identity mismatch")
        sequence = message.get("sequence")
        if isinstance(sequence, bool) or not isinstance(sequence, int) or sequence <= self._inbound_sequence:
            raise QuasarProtocolError("Project bridge sequence is invalid")
        self._inbound_sequence = sequence
        if expected_type and message.get("type") != expected_type:
            raise QuasarProtocolError(f"Expected {expected_type}")
        if not isinstance(message.get("payload"), dict):
            raise QuasarProtocolError("Project bridge payload must be an object")

    def _send(self, message_type: str, payload: dict[str, Any], request_id: Optional[str] = None) -> None:
        with self._sequence_lock:
            self._sequence += 1
            message = {
                "protocolVersion": PROTOCOL_VERSION,
                "sessionId": self._session_id,
                "sequence": self._sequence,
                "type": message_type,
                "payload": payload,
            }
            if request_id is not None:
                message["requestId"] = request_id
            self._socket.send_json(message)

    def _assert_open(self) -> None:
        if self._closed.is_set():
            if isinstance(self._reader_error, QuasarConnectionError):
                raise self._reader_error._fresh() from None
            if isinstance(self._reader_error, BaseException):
                raise QuasarConnectionError(str(self._reader_error)) from None
            raise QuasarConnectionError("Project bridge client is closed")

    def _maybe_ping(self) -> None:
        if time.monotonic() - self._last_ping >= 10:
            self._send("session.ping", {"sentAtMs": int(time.time() * 1000)})
            self._last_ping = time.monotonic()

    @staticmethod
    def _deadline(timeout: Optional[float]) -> Optional[float]:
        if timeout is None:
            return None
        timeout_value = float(timeout)
        if not math.isfinite(timeout_value) or timeout_value < 0:
            raise ValueError("timeout must be finite and non-negative")
        return time.monotonic() + timeout_value

    @staticmethod
    def _remaining_wait(deadline: Optional[float], timeout_message: str) -> float:
        if deadline is None:
            return 0.1
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise QuasarTimeoutError(timeout_message)
        return min(0.1, remaining)

    def _fail_pending(self, error: BaseException) -> None:
        with self._pending_lock:
            pending = list(self._pending.values())
        for response_queue in pending:
            try:
                response_queue.put_nowait({"_client_error": error})
            except queue.Full:
                pass

    @staticmethod
    def _put_bounded(target: queue.Queue[Any], value: Any) -> None:
        try:
            target.put_nowait(value)
        except queue.Full:
            try:
                target.get_nowait()
            except queue.Empty:
                pass
            target.put_nowait(value)

    @staticmethod
    def _next(target: queue.Queue[Any], timeout: Optional[float]) -> Any:
        if timeout is not None and timeout < 0:
            raise ValueError("timeout must be non-negative")
        try:
            return target.get(timeout=timeout)
        except queue.Empty as error:
            raise QuasarTimeoutError("Subscription timed out") from error


__all__ = [
    "QuasarClient",
    "QuasarClientError",
    "QuasarCommandError",
    "QuasarConfigurationError",
    "QuasarConnectionError",
    "QuasarProtocolError",
    "QuasarRunStoppedError",
    "QuasarTimeoutError",
    "RuntimeEvent",
    "TelemetrySample",
]
